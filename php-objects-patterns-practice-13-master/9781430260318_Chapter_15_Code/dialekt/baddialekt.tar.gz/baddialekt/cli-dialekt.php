<?php
require_once( "Dialekt.php" );
print "This is the Dialekt command line interface!\n";
?>

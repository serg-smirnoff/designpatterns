<?php
print "I am a Ali G\n";
?>
